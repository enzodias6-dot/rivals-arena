# 3. Diagrama Entidade-Relacionamento (DER)

Notação *crow's foot* (pé de galinha). Arquivos: [`diagramas/der.png`](diagramas/der.png) · [`der.svg`](diagramas/der.svg) (vetorial) · [`der.mmd`](diagramas/der.mmd) (código Mermaid editável; renderiza direto no GitHub).

![DER — Rivals Arena](diagramas/der.png)

## Legenda

| Símbolo | Significado |
|---|---|
| `PK` | Chave primária |
| `FK` | Chave estrangeira |
| `‖` (dois traços) | Exatamente um |
| `o‖` / `o|` | Zero ou um |
| `o{` | Zero ou muitos |
| Campos marcados *proposto* | `times` e `membros_time` — ver `02-modelagem-logica.md` §2.6 |

## Cardinalidades resumidas

| Relacionamento | Cardinalidade |
|---|---|
| AUTH_USERS — USUARIOS | 1 : 1 |
| USUARIOS — CAMPEONATOS (criador) | 1 : N |
| USUARIOS — INSCRICOES — CAMPEONATOS | N : M (tabela associativa `inscricoes`) |
| USUARIOS — DESAFIOS — USUARIOS | N : M autorrelacionamento (`desafiante_id`, `desafiado_id`) |
| CAMPEONATOS — PARTIDAS | 1 : N (partida pode não ter campeonato) |
| USUARIOS — PARTIDAS | 3 vínculos: `jogador_1_id`, `jogador_2_id` (obrigatórios), `vencedor_id` (opcional) |
| USUARIOS — MEMBROS_TIME — TIMES | N : M (proposto) |

## Código-fonte (Mermaid)

```mermaid
erDiagram
    AUTH_USERS ||--|| USUARIOS : "tem perfil (trigger)"
    USUARIOS ||--o{ CAMPEONATOS : "cria"
    USUARIOS ||--o{ INSCRICOES : "realiza"
    CAMPEONATOS ||--o{ INSCRICOES : "recebe"
    USUARIOS ||--o{ DESAFIOS : "desafiante"
    USUARIOS ||--o{ DESAFIOS : "desafiado"
    CAMPEONATOS |o--o{ PARTIDAS : "organiza"
    USUARIOS ||--o{ PARTIDAS : "jogador_1"
    USUARIOS ||--o{ PARTIDAS : "jogador_2"
    USUARIOS |o--o{ PARTIDAS : "vencedor"
    USUARIOS ||--o{ MEMBROS_TIME : "participa"
    TIMES ||--o{ MEMBROS_TIME : "reune"

    AUTH_USERS {
        uuid id PK
        varchar email
        text senha_hash "gerida pelo Supabase Auth"
    }
    USUARIOS {
        uuid id PK, FK "= auth.users.id"
        varchar nome "2 a 80 caracteres"
        varchar email
        varchar perfil
        varchar nivel
        int pontos "default 0"
        int vitorias "default 0"
        int derrotas "default 0"
    }
    CAMPEONATOS {
        uuid id PK
        uuid criador_id FK
        varchar nome "ate 150 caracteres"
        text descricao
        varchar modalidade "1v1, dupla, equipes, solo"
        varchar formato "eliminacao_simples, grupos, pontos"
        int max_participantes "2 a 64"
        timestamptz inicio_em
        timestamptz encerramento_em
        varchar premio
        varchar status "aberto, em_breve, encerrado"
    }
    INSCRICOES {
        uuid id PK
        uuid campeonato_id FK
        uuid jogador_id FK
        varchar status "pendente, aprovada, cancelada"
        timestamptz inscrito_em
    }
    DESAFIOS {
        uuid id PK
        uuid desafiante_id FK
        uuid desafiado_id FK
        varchar status "pendente, aceito, recusado"
        timestamptz data_criacao
    }
    PARTIDAS {
        uuid id PK
        uuid campeonato_id FK "opcional"
        uuid jogador_1_id FK
        uuid jogador_2_id FK
        uuid vencedor_id FK "nulo ate concluir"
        varchar fase
        varchar status
        varchar resultado
        timestamptz concluida_em
    }
    TIMES {
        uuid id PK
        varchar nome "proposto"
    }
    MEMBROS_TIME {
        uuid time_id PK, FK "proposto"
        uuid usuario_id PK, FK "proposto"
    }
```
