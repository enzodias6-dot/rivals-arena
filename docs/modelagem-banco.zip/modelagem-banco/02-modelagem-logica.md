# 2. Modelagem Lógica

Tradução do modelo conceitual para o modelo relacional (PostgreSQL/Supabase): tabelas, tipos, chaves e restrições. Diagrama completo em [`03-der.md`](03-der.md).

> Legenda de origem: ✅ confirmado no código · 🔶 inferido (tipo/restrição provável, conferir no painel Supabase) · 📝 proposto (não consta no código).

Convenções: PK = chave primária · FK = chave estrangeira · UQ = única · NN = não nulo. Todos os IDs são `uuid` (padrão `gen_random_uuid()`).

## 2.1 `usuarios` — perfil do jogador

| Coluna | Tipo | Restrições | Origem |
|---|---|---|---|
| `id` | uuid | **PK**, **FK → auth.users(id)** | ✅ (criado por trigger no cadastro) |
| `nome` | varchar(80) | NN, 2–80 caracteres | ✅ |
| `email` | varchar(254) | NN, UQ | ✅ |
| `perfil` | varchar | — (papel/tipo do perfil) | ✅ coluna / 🔶 domínio |
| `nivel` | varchar ou int | — | ✅ coluna / 🔶 tipo |
| `pontos` | int | NN, default 0 | ✅ |
| `vitorias` | int | NN, default 0, ≥ 0 | ✅ |
| `derrotas` | int | NN, default 0, ≥ 0 | ✅ |

Índice sugerido: `(pontos DESC, vitorias DESC)` para o ranking.

## 2.2 `campeonatos`

| Coluna | Tipo | Restrições | Origem |
|---|---|---|---|
| `id` | uuid | **PK** | ✅ |
| `criador_id` | uuid | NN, **FK → usuarios(id)** | ✅ |
| `nome` | varchar(150) | NN | ✅ |
| `descricao` | text | — | ✅ |
| `modalidade` | varchar | CHECK ∈ (`1v1`,`dupla`,`equipes`,`solo`) | ✅ |
| `formato` | varchar | CHECK ∈ (`eliminacao_simples`,`grupos`,`pontos`) | ✅ |
| `max_participantes` | int | NN, CHECK 2 ≤ valor ≤ 64 | ✅ |
| `inicio_em` | timestamptz | — | ✅ |
| `encerramento_em` | timestamptz | — , CHECK ≥ `inicio_em` | ✅ / 🔶 CHECK |
| `premio` | varchar | — | ✅ |
| `status` | varchar | NN, default `aberto`, CHECK ∈ (`aberto`,`em_breve`,`encerrado`) | ✅ |

## 2.3 `inscricoes` — associativa Jogador × Campeonato

| Coluna | Tipo | Restrições | Origem |
|---|---|---|---|
| `id` | uuid | **PK** | ✅ |
| `campeonato_id` | uuid | NN, **FK → campeonatos(id)** | ✅ |
| `jogador_id` | uuid | NN, **FK → usuarios(id)** | ✅ |
| `status` | varchar | NN, default `pendente`, CHECK ∈ (`pendente`,`aprovada`,`cancelada`) | ✅ |
| `inscrito_em` | timestamptz | NN, default `now()` | ✅ |

Unicidade recomendada: índice único **parcial** `(campeonato_id, jogador_id) WHERE status IN ('pendente','aprovada')`. Assim o jogador pode se reinscrever depois de cancelar, o que o código permite. Uma UQ simples `(campeonato_id, jogador_id)` impediria a reinscrição.

## 2.4 `desafios` — auto-relacionamento Jogador × Jogador

| Coluna | Tipo | Restrições | Origem |
|---|---|---|---|
| `id` | uuid | **PK** | ✅ |
| `desafiante_id` | uuid | NN, **FK → usuarios(id)** | ✅ |
| `desafiado_id` | uuid | NN, **FK → usuarios(id)**, CHECK `<> desafiante_id` | ✅ / 🔶 CHECK |
| `status` | varchar | NN, default `pendente`, CHECK ∈ (`pendente`,`aceito`,`recusado`) | ✅ |
| `data_criacao` | timestamptz | NN, default `now()` | ✅ |

Unicidade recomendada: índice único parcial no par **não ordenado** `(LEAST(desafiante_id, desafiado_id), GREATEST(desafiante_id, desafiado_id)) WHERE status = 'pendente'`. Isso garante no banco a regra "um desafio pendente por par, nos dois sentidos", hoje verificada só na aplicação.

## 2.5 `partidas`

| Coluna | Tipo | Restrições | Origem |
|---|---|---|---|
| `id` | uuid | **PK** | ✅ |
| `campeonato_id` | uuid | **FK → campeonatos(id)**, **nulável** (partida avulsa) | ✅ |
| `jogador_1_id` | uuid | NN, **FK → usuarios(id)** | ✅ |
| `jogador_2_id` | uuid | NN, **FK → usuarios(id)**, CHECK `<> jogador_1_id` | ✅ / 🔶 CHECK |
| `vencedor_id` | uuid | **FK → usuarios(id)**, nulável, CHECK ∈ {`jogador_1_id`,`jogador_2_id`} | ✅ / 🔶 CHECK |
| `fase` | varchar | — (ex.: quartas, semifinal, final) | ✅ |
| `status` | varchar | — (ex.: agendada, concluída) | ✅ coluna / 🔶 domínio |
| `resultado` | varchar | — (ex.: placar em texto) | ✅ |
| `concluida_em` | timestamptz | nulo até a partida terminar | ✅ |

Observação: o schema Supabase **não** possui `perdedor_id` nem placares numéricos (o legado MySQL possuía). O perdedor é derivado: o jogador que não é o `vencedor_id`.

## 2.6 `times` e `membros_time` — 📝 propostos

| Tabela | Coluna | Tipo | Restrições |
|---|---|---|---|
| `times` | `id` | uuid | **PK** |
| | `nome` | varchar(80) | NN, UQ |
| | `lider_id` | uuid | **FK → usuarios(id)** (opcional) |
| `membros_time` | `time_id` | uuid | **PK (composta)**, **FK → times(id)** ON DELETE CASCADE |
| | `usuario_id` | uuid | **PK (composta)**, **FK → usuarios(id)** ON DELETE CASCADE |

Se o schema real tiver colunas diferentes, ajuste esta seção; as relações (N:M por tabela associativa) permanecem.

## 2.7 Views

| View | Finalidade | Colunas usadas pelo código |
|---|---|---|
| `vw_perfis_publicos` | Perfis sem dados sensíveis (busca de adversário, nomes no histórico) | `id`, `nome` |
| `vw_ranking` / `vw_ranking_publico` | Ranking público dos jogadores | `id`, `nome`, `pontos`, `vitorias`, `derrotas` |

## 2.8 Regras de integridade referencial (ações de FK)

| Relação | Sugestão | Motivo |
|---|---|---|
| `usuarios.id → auth.users.id` | ON DELETE CASCADE | Apagar a conta remove o perfil. |
| `inscricoes → campeonatos / usuarios` | CASCADE | Inscrição não existe sem os dois lados. |
| `desafios → usuarios` | CASCADE | Idem. |
| `campeonatos.criador_id → usuarios` | RESTRICT ou SET NULL | Evita perder campeonatos ao apagar o criador. |
| `partidas.campeonato_id → campeonatos` | SET NULL | A partida vira avulsa (mantém o histórico). |
| `partidas.jogador_*_id / vencedor_id → usuarios` | RESTRICT | Preserva histórico e pontuação. |

> No legado MySQL, os mesmos relacionamentos usavam CASCADE/SET NULL; as ações acima são recomendações para o PostgreSQL e devem ser conferidas contra o banco real.

## 2.9 Normalização

- **1FN:** todos os atributos são atômicos; sem grupos repetitivos (inscrições, desafios e partidas são tabelas próprias, não listas dentro de `usuarios`).
- **2FN:** as tabelas com chave simples (`uuid`) não têm dependência parcial; nas associativas, os atributos (`status`, `inscrito_em`) dependem da inscrição como um todo.
- **3FN:** não há dependência transitiva — o nome do campeonato ou do jogador não é copiado para `inscricoes`, `partidas` ou `desafios`; as consultas usam JOIN/`IN` por id.
- **Desnormalização consciente:** `pontos`, `vitorias` e `derrotas` em `usuarios` são **derivados** das partidas. Mantê-los na tabela dá leitura rápida do ranking; em troca, é preciso atualizá-los quando uma partida é concluída. Como as regras de pontuação ainda não foram definidas pela equipe, essa atualização é feita direto no banco. A sugestão é um trigger ou função (RPC) ao concluir a partida.

## 2.10 Pontos de atenção

1. **Limite de vagas não atômico:** a contagem de inscrições é checada na aplicação; duas inscrições simultâneas na última vaga podem passar. Solução: função/trigger no banco que valide a contagem com trava (`SELECT … FOR UPDATE` no campeonato).
2. **Unicidade e CHECKs** acima: hoje parte das regras vive só no backend; replicá-las no banco garante a integridade mesmo fora da API.
3. **RLS:** contagens e vagas dependem das linhas que a política deixa o usuário ler.
