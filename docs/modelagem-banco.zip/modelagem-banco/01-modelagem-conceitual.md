# 1. Modelagem Conceitual

Nível independente de SGBD: descreve **o que** o sistema guarda e como as coisas se relacionam. Diagrama: [`diagramas/conceitual.png`](diagramas/conceitual.png).

![Modelo conceitual](diagramas/conceitual.png)

## 1.1 Entidades e atributos

| Entidade | Descrição | Atributos |
|---|---|---|
| **JOGADOR** (tabela `usuarios`) | Pessoa cadastrada na plataforma (“combatente”). | nome, email, perfil, nível, pontos, vitórias, derrotas |
| **CAMPEONATO** (`campeonatos`) | Torneio criado por um jogador e aberto a inscrições. | nome, descrição, modalidade, formato, máx. participantes, início, encerramento, prêmio, status |
| **PARTIDA** (`partidas`) | Confronto entre dois jogadores, dentro de um campeonato ou avulso. | fase, status, resultado, data de conclusão |
| **TIME** (`times`) — _proposto_ | Agrupamento de jogadores (página Times). | nome |

Entidades associativas (nascem de relacionamentos N:M): **INSCRIÇÃO** (jogador × campeonato), **DESAFIO** (jogador × jogador) e **MEMBRO_TIME** (jogador × time, _proposto_).

Fora do domínio, o **Supabase Auth** (`auth.users`) guarda credenciais; o jogador é 1:1 com a conta de autenticação (senha nunca fica em `usuarios`).

## 1.2 Relacionamentos e cardinalidades

| # | Relacionamento | Cardinalidade | Leitura |
|---|---|---|---|
| R1 | Conta de acesso — Jogador | 1 : 1 | Cada conta tem exatamente um perfil, criado por trigger no cadastro. |
| R2 | Jogador **cria** Campeonato | 1 : N | Um jogador cria vários campeonatos; cada campeonato tem um criador. |
| R3 | Jogador **se inscreve** em Campeonato | N : M (via INSCRIÇÃO) | Um jogador em vários campeonatos; um campeonato com vários jogadores. Atributos do relacionamento: status e data da inscrição. |
| R4 | Jogador **desafia** Jogador | N : M auto-relacionamento (via DESAFIO) | Papéis *desafiante* e *desafiado*. Atributos: status, data. |
| R5 | Campeonato **organiza** Partida | 1 : N, participação **opcional** da partida | Uma partida pode existir sem campeonato (confronto avulso/desafio). |
| R6 | Jogador **disputa** Partida | N : M, com dois papéis fixos (*jogador 1*, *jogador 2*) | Toda partida tem exatamente dois jogadores. |
| R7 | Jogador **vence** Partida | 0..1 : N | O vencedor é um dos dois jogadores e só existe após a conclusão. |
| R8 | Jogador **integra** Time — _proposto_ | N : M (via MEMBRO_TIME) | Um jogador em vários times; um time com vários jogadores. |

## 1.3 Regras de negócio que o modelo precisa sustentar

Extraídas do código (`src/routes`, `src/utils/validacao.js`):

1. **Cadastro:** nome de 2 a 80 caracteres, sem caracteres de controle; email único e válido.
2. **Campeonato:** nome obrigatório (até 150 caracteres); `max_participantes` inteiro entre **2 e 64**; modalidade ∈ {`1v1`, `dupla`, `equipes`, `solo`}; formato ∈ {`eliminacao_simples`, `grupos`, `pontos`}; status ∈ {`aberto`, `em_breve`, `encerrado`}; nasce como `aberto`, com o criador definido pelo usuário autenticado.
3. **Inscrição:** só em campeonato `aberto`; um jogador não pode ter duas inscrições ativas (`pendente`/`aprovada`) no mesmo campeonato; **o número de inscrições ativas não pode ultrapassar `max_participantes`**; o jogador pode cancelar (status `cancelada`, sem apagar o registro — preserva o histórico).
4. **Desafio:** não pode haver desafio `pendente` entre o mesmo par de jogadores (nos dois sentidos); só o **desafiado** responde, uma única vez, mudando `pendente` → `aceito` ou `recusado`.
5. **Partida:** possui dois jogadores; o vencedor, quando definido, é um deles; só partidas com `concluida_em` entram no histórico.
6. **Ranking:** ordenado por pontos (desc), vitórias (desc) e id; a posição do perfil usa o mesmo critério.
7. **Acesso:** cada operação autenticada respeita as políticas RLS do Supabase (dados públicos expostos por views, sem email).
