# Modelagem do Banco de Dados — Rivals Arena

Entrega do item **4. Modelagem do banco de dados** do Projeto Integrador (EP 190 – Rivals Arena).

| Arquivo | Conteúdo |
|---|---|
| [`01-modelagem-conceitual.md`](01-modelagem-conceitual.md) | Entidades, atributos, relacionamentos, cardinalidades e regras de negócio |
| [`02-modelagem-logica.md`](02-modelagem-logica.md) | Tabelas, tipos, chaves primárias/estrangeiras, restrições, índices e normalização |
| [`03-der.md`](03-der.md) | Diagrama Entidade-Relacionamento (DER) com legenda |
| `diagramas/der.png` · `der.svg` · `der.mmd` | DER (imagem, vetor e código-fonte Mermaid) |
| `diagramas/conceitual.png` · `conceitual.svg` · `conceitual.mmd` | Diagrama do modelo conceitual |

## Base da modelagem

O banco em uso é o **Supabase (PostgreSQL + Auth)**, conforme o `README.md` e o `RELATORIO.md` do projeto. A modelagem foi levantada a partir do código real (`src/routes/*.js`, `src/utils/validacao.js`) e **não** do `database/schema.sql`, que é o MySQL legado (tabelas `torneios`, `inscricoes`, IDs inteiros) e foi mantido apenas até a validação da migração.

### O que é confirmado e o que é proposto

- **Confirmado no código:** `usuarios`, `campeonatos`, `inscricoes`, `desafios`, `partidas` e as views `vw_perfis_publicos`, `vw_ranking`, `vw_ranking_publico`.
- **Proposto (marcado como _proposto_):** `times` e `membros_time`. O README as lista como parte do schema, mas nenhuma rota as consulta e suas colunas não estão versionadas. As colunas dessas duas tabelas e os tipos exatos das demais (`varchar` × `text`, `CHECK` × enum) devem ser conferidos no painel do Supabase.
- As políticas RLS não estão versionadas no repositório e, por isso, não constam aqui.
